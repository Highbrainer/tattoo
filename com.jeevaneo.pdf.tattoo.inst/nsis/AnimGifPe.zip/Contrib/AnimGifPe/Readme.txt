AnimGig.dll - plug-in that shows animated banner on the installer' page. 
OlegBykov CPictureEx based GIF decoder. Decodes all GIF images I could 
find and static BMP, GIF, JPEG. But works slowly on old comps, one frame 
(160x300) extraction may takes up to 100 ms on PII-400. This is 
OleLoadPicture delay problem and currently I have not ideas how to improve 
situation. If you need faster code, use AnimGifFast.zip version - works 
up to 100 times faster, but not supports some images (but if fast version 
works on test, it shall work everywhere, because all code is inside). 
Compare to 'fast' version this plug-in is 3 kB bigger.

Usage:

1)   AnimGif::play /NOUNLOAD [/HALIGN=POSX] [/VALIGN=POSY] [/HWND=xxx] [/BGCOL=xxx] [/FIT=WIDTH|HEIGHT|BOTH] FileName

FileName - image filename. Bmp, gif and jpg image types are supported.
           Empty Filename string "" cleares image but not stops sound playing.

HALIGN - alignment (on the target window) in percents of window width, default 50 (center)

VALIGN - alignment (on the target window) in percents of window height, default 100 (bottom)

HWND - target window handle, current page #32770 child is default.

BGCOL - color to use for image trasparent areas. If not defined, plug-in attempts
        to extract value from target window, but this is not possible if window is hidden.
        Color value may be hex (starting with 0x) and decimal (first is not 0). Hex value 
        will be used as RGB color, decimal - as Windows system color index in GetSysColor()
        API call, see MSDN. If value not specified and target window stays hidden (for
        example in custom 'Show' function), default COLOR_BTNFACE will be used.

FIT - image stretch to occupy window width or height. For screen dpi 120 mainly.
      Default - no stretch.

For example:

     AnimGif::play /NOUNLOAD "$PLUGINSDIR\felix_new.gif"

2)   AnimGif::stop

     stops playing and clears window


Takhir Bedertdinov
